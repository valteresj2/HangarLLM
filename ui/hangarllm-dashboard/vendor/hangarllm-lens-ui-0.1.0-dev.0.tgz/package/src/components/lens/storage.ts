export const FINDING_PANEL_WIDTH_KEY = "hangarllm.lens.findingPanelWidth";
